//������� 2
#include <iostream>
#include "linear_systems.h"

int main()
{
	using namespace std;

	size_t n = 3;
	size_t m = n + 1;
	std::vector<std::vector<float>> matrix(n, std::vector<float>(m));

	matrix[0][0] = 2;
	matrix[0][1] = 5;
	matrix[0][2] = 2;
	matrix[0][3] = 8;

	matrix[1][0] = 3;
	matrix[1][1] = 4;
	matrix[1][2] = 2;
	matrix[1][3] = 15;

	matrix[2][0] = 3;
	matrix[2][1] = 5;
	matrix[2][2] = 18;
	matrix[2][3] = 66;

	std::vector<float> gaussSolution(n);

	gauss(matrix, gaussSolution);

	for (size_t i = 0; i < gaussSolution.size(); ++i)
	{
		cout << "x[" << (i + 1) << "] = " << gaussSolution[i] << endl;
	}

	return 0;
}
