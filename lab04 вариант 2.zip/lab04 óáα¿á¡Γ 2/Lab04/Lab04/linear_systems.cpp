#include "linear_systems.h"

void gauss(const std::vector<std::vector<float>>& matrix_,
	std::vector<float>& solution)
{
	// ����������� �������.
	std::vector<std::vector<float>> matrix(matrix_);

	int n = matrix.size();
	int m = n + 1;

	for (int k = 0; k < n; ++k)
	{
		
		float temp = matrix[k][k];

		for (int j = k; j < m; ++j)
		{
			matrix[k][j] /= temp;
		}

		for (int i = k + 1; i < n; ++i)
		{
			float temp = matrix[i][k];

			for (int j = k; j < m; ++j)
			{
				matrix[i][j] -= temp * matrix[k][j];
			}
		}
	}

	solution[n - 1] = matrix[n - 1][m - 1];

	for (int k = n - 2; k >= 0; --k)
	{
		float sum = 0;

		for (int j = k + 1; j < n; ++j)
		{
			sum += matrix[k][j] * solution[j];
		}

		solution[k] = matrix[k][m - 1] - sum;
	}
}
