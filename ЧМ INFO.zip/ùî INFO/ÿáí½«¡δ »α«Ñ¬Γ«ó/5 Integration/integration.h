
#ifndef __INTEGRATION_H__
#define __INTEGRATION_H__

#include <functional>

float leftTriangles(std::function<float(float)> f,
	float a, float b, float h = 0.001);

#endif
