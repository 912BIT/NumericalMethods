﻿
#include <iostream>
#include <functional>
#include "integration.h"

int main()
{
	using namespace std;
	
	//  ∫ 5x^2 + x
	auto f = [](float x) { return 5 * x * x + x; };

	float a = 0, b = 8;

	float leftTrianglesResult = leftTriangles(f, a, b);
	cout << "Integral 5x^2 + x = " << leftTrianglesResult << endl;

	return 0;
}
