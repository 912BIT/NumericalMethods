
#include "integration.h"

float leftTriangles(std::function<float(float)> f,
	float a, float b, float h)
{
	float integral = 0;
	// ...
	return integral;
}
