
#include "interpolation.h"

float lagrange(const std::vector<float>& x, const std::vector<float>& y,
	float arg)
{
	assert(x.size() == y.size());

	float polynomial = 0;
	// ...
	return polynomial;
}
