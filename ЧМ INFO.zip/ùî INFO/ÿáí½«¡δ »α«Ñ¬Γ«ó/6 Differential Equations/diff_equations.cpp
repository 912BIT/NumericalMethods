
#include "diff_equations.h"

std::vector<float> euler(std::function<float(float, float)> f,
	float a, float b, float h)
{
	std::vector<float> y;
	
	// ...

	return y;
}
