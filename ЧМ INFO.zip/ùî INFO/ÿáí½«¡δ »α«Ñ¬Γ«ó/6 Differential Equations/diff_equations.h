
#ifndef __DIFF_EQUATIONS_H__
#define __DIFF_EQUATIONS_H__

#include <vector>
#include <functional>

std::vector<float> euler(std::function<float(float, float)> f,
	float a, float b, float h = 0.2);

#endif
