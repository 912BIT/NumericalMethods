﻿
#include <iostream>
#include <functional>
#include "diff_equations.h"

int main()
{
	using namespace std;
	
	//  y' = y + x
	auto f = [](float x, float y) { return y + x; };

	float a = 0, b = 1, h = 0.2f;

	std::vector<float> yEuler = euler(f, a, b, h);

	// Вывод результата (набор точек).
	float x = a;
	for (size_t i = 0; i < yEuler.size(); x += h, ++i)
	{
		cout << "(" << x << "; " << yEuler[i] << ") ";
	}

	return 0;
}
