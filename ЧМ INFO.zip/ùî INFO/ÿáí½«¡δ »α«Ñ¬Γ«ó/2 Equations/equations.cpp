﻿
#include "equations.h"

float dichotomy(std::function<float(float)> f,
	float a, float b, float epsilon)
{
	float x = 0;
	// ...
	return x;
}
                                                                               