
#include <iostream>
#include <functional>
#include "equations.h"

int main()
{
	using namespace std;

	// x^2 - 34 = 0
	auto f = [=](float x) { return x * x - 34; };

	float a = 0, b = 8;

	float xDichotomy = dichotomy(f, a, b);
	cout << "x = " << xDichotomy << endl;

	return 0;
}
