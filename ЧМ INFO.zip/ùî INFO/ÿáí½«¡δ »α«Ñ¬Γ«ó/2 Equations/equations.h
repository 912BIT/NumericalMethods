﻿
#ifndef __EQUATIONS_H__
#define __EQUATIONS_H__

#include <functional>

float dichotomy(std::function<float(float)> f,
	float a, float b, float epsilon = .0001f);

#endif
